﻿using AutoMapper;
using Bosch.eCommerce.Models;
using Bosch.eCommerce.Mvc.UI.DTOs.CartItemDtos;
using Bosch.eCommerce.Persistance;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Bosch.eCommerce.Mvc.UI.Areas.Carts.Controllers
{
    [Area("Carts")]
    public class HomeController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly ICommonRepository<CartItem> _cartItemRepository;
        private readonly IGenerateCart _generateCart;
        private readonly IMapper _mapper;
        public HomeController(IConfiguration configuration, ICommonRepository<CartItem> cartItemRepository, IGenerateCart generateCart, IMapper mapper)
        {
            _configuration = configuration;
            _cartItemRepository = cartItemRepository;
            _generateCart = generateCart;
            _mapper = mapper;
        }

        // Action to display cart items
        public async Task<IActionResult> YourCartItems()
        {
            if (HttpContext.Session.GetInt32("CartId") == null)
            {
                ViewBag.NoItemsInCartMessage = "Your Cart is Empty";
                return View();
            }
            var cartDetailsData = await _generateCart.GetCartItems((int)HttpContext.Session.GetInt32("CartId"));
            if (cartDetailsData.Count <= 0)
            {
                ViewBag.NoItemsInCartMessage = "Your Cart is Empty";
            }
            return View(cartDetailsData);
        }
        public async Task<IActionResult> AddToCart(int productId)
        {
            HttpContext.Session.SetInt32("CustomerId", 1);
            if (HttpContext.Session.GetInt32("CartId") == null)
            {
                int cartId = await _generateCart.GenerateNewCart((int)HttpContext.Session.GetInt32("CustomerId"));
                HttpContext.Session.SetInt32("CartId", cartId);
            }
            var cartItemDto = new InsertCartItemDto()
            {
                CartId = (int)HttpContext.Session.GetInt32("CartId"),
                ProductId = productId,
            };
            var cartItem = _mapper.Map<CartItem>(cartItemDto);
            int result = await _cartItemRepository.InsertAsync(cartItem);
            if (result > 0)
            {
                return RedirectToAction("YourCartItems");
            }

            return RedirectToAction("AddToCart");
        }

        // Action to handle the checkout process and generate Razorpay order details
        [HttpPost]
        public async Task<IActionResult> InitiateCheckout()
        {
            try
            {
                var razorpayKey = _configuration["Razorpay:Key"];
                var razorpaySecret = _configuration["Razorpay:Secret"];

                // Generate Razorpay order
                var order = await CreateRazorpayOrder();
                return Json(new
                {
                    key = razorpayKey,
                    orderId = order.Id,
                    amount = order.Amount,
                    currency = order.Currency
                });
            }
            catch (Exception ex)
            {
                // Log the exception and return an error message
                // You can log the exception using a logging framework
                return StatusCode(500, new { error = ex.Message });
            }
        }

        private async Task<RazorpayOrder> CreateRazorpayOrder()
        {
            var razorpayKey = _configuration["Razorpay:Key"];
            var razorpaySecret = _configuration["Razorpay:Secret"];

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes($"{razorpayKey}:{razorpaySecret}")));

                var orderData = new
                {
                    amount = 1000, // Amount in paise (e.g., 1000 paise = 10 INR)
                    currency = "INR",
                    receipt = "receipt#1",
                    payment_capture = 1
                };

                var jsonOrderData = JsonConvert.SerializeObject(orderData);
                var httpContent = new StringContent(jsonOrderData, Encoding.UTF8, "application/json");

                var httpResponse = await client.PostAsync("https://api.razorpay.com/v1/orders", httpContent);

                if (!httpResponse.IsSuccessStatusCode)
                {
                    var responseContent = await httpResponse.Content.ReadAsStringAsync();
                    throw new Exception($"Razorpay API Error: {responseContent}");
                }

                var orderContent = await httpResponse.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<RazorpayOrder>(orderContent);
            }
        }
    }

    public class RazorpayOrder
    {
        public string Id { get; set; }
        public int Amount { get; set; }
        public string Currency { get; set; }
    }
}

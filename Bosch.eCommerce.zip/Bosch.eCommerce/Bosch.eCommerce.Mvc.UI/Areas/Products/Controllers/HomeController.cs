﻿using Bosch.eCommerce.Models;
using Bosch.eCommerce.Persistance;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bosch.eCommerce.Mvc.UI.Areas.Products.Controllers
{
    [Area("Products")]
    public class HomeController : Controller
    {
        private readonly ICommonRepository<Product> _productRepository;
        private readonly ICommonRepository<Category> _categoryRepository;
        private readonly IMemoryCache _productsCache;

        public HomeController(ICommonRepository<Product> productRepository, ICommonRepository<Category> categoryRepository, IMemoryCache productsCache)
        {
            _productRepository = productRepository;
            _categoryRepository = categoryRepository;
            _productsCache = productsCache;
        }

        public async Task<IActionResult> Index(int pageNumber = 1, int pageSize = 8)
        {
            ViewBag.PageTitle = "Welcome to Bosch ProductList!";

            // Fetch products directly from repository
            var products = await _productRepository.GetAllAsync();

            // Calculate the total number of products
            var totalProducts = products.Count();

            // Apply pagination
            var paginatedProducts = products.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();

            // Create the view model
            var viewModel = new ProductListViewModel
            {
                Products = paginatedProducts,
                Pagination = new PaginationModel
                {
                    CurrentPage = pageNumber,
                    ItemsPerPage = pageSize,
                    TotalItems = totalProducts
                }
            };

            return View(viewModel);
        }

        public async Task<IActionResult> Details(int id)
        {
            var product = await _productRepository.GetDetailsAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            ViewBag.PageTitle = $"Details of - {product.ProductName}!";
            return View(product);
        }

        public async Task<IActionResult> CategoryWiseProducts(int id, int pageNumber = 1, int pageSize = 8)
        {
            var category = await _categoryRepository.GetDetailsAsync(id);
            if (category == null)
            {
                return NotFound();
            }
            string categoryName = category.CategoryName;
            ViewBag.PageTitle = $"Welcome to Bosch ProductList {categoryName}!";

            var products = (await _productRepository.GetAllAsync()).Where(product => product.CategoryId == id);
            var totalProducts = products.Count();
            var paginatedProducts = products.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();

            var viewModel = new ProductListViewModel
            {
                Products = paginatedProducts,
                Pagination = new PaginationModel
                {
                    CurrentPage = pageNumber,
                    ItemsPerPage = pageSize,
                    TotalItems = totalProducts
                }
            };

            return View("Index", viewModel);
        }
    }
}

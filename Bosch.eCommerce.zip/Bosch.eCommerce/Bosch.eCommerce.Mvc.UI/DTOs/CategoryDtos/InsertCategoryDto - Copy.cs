﻿namespace Bosch.eCommerce.Mvc.UI.DTOs.CategoryDtos
{
    public class InsertCategoryDto
    {
     
        public string CategoryName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }
}

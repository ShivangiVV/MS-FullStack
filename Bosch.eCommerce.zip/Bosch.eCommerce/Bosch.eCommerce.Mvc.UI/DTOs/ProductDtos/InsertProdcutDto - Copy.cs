﻿namespace Bosch.eCommerce.Mvc.UI.DTOs.ProductDtos
{
    public class InsertProdcutDto
    {
    }
}

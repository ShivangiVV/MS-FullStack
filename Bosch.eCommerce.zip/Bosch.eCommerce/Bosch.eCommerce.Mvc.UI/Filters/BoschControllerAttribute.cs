﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace Bosch.eCommerce.Mvc.UI.Filters
{
    public class BoschControllerAttribute : Attribute, IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext context)
        {
            Console.WriteLine("Im CONTROLLER Action Method - OnActionExecuTED");
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            Console.WriteLine("Im CONTROLLER Action Method - OnActionExecuTING");
            
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace Bosch.eCommerce.Mvc.UI.Filters
{
    public class GlobalFilter : IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext context)
        {
            Console.WriteLine("Im GLOBAL FILTER Action Method - OnActionExecuTED");
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            Console.WriteLine("Im GLOBAL FILTER Action Method - OnActionExecuTING");

        }
    }
}

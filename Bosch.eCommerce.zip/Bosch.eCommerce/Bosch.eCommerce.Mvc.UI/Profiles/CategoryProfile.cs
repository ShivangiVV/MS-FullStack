﻿using AutoMapper;
using Bosch.eCommerce.Models;
using Bosch.eCommerce.Mvc.UI.DTOs.CategoryDtos;

namespace Bosch.eCommerce.Mvc.UI.Profiles
{
    public class CategoryProfile:Profile    
    {
        public CategoryProfile()
        {
            //Featch data to be displayed in view
            CreateMap<Category,CategoryDto>();
            
            //Insert/Update/Delete Operations
            CreateMap<InsertCategoryDto,Category>();

        }
    }
}

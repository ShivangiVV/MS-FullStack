﻿document.addEventListener('DOMContentLoaded', function () {
    var razorpayKey = 'your-razorpay-key'; // Replace with your Razorpay key

    document.getElementById('proceedToCheckoutButton').onclick = function () {
        var options = {
            "key": razorpayKey,
            "amount": "1000", // Amount in paise (i.e., 1000 paise = 10 INR)
            "currency": "INR",
            "name": "Your Company Name",
            "description": "Test Transaction",
            "image": "https://example.com/your_logo.png", // Optional logo
            "handler": function (response) {
                // Handle payment response
                alert("Payment successful: " + response.razorpay_payment_id);
                // Redirect to a success page or similar
                window.location.href = '/Cart/Success'; // Modify as needed
            },
            "prefill": {
                "name": "Customer Name",
                "email": "customer@example.com",
                "contact": "9999999999"
            },
            "theme": {
                "color": "#3399cc"
            }
        };

        // Create a Razorpay instance and open the checkout form
        var rzp1 = new Razorpay(options);
        rzp1.open();
    };
});

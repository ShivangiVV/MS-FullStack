﻿using Bosch.eCommerce.Models;

namespace Bosch.eCommerce.Persistance
{
    public interface IGenerateCart
    {
        Task<int> GenerateNewCart(int Customerid);
     
        Task<List<MyCartVM>> GetCartItems(int cartId);
    }
}

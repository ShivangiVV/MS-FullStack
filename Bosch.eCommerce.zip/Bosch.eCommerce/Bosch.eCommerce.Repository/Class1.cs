﻿namespace Bosch.eCommerce.Repository
{
    public class Class1
    {

    }
}
